my_list = ["ab", "abc", "b", "zzza", "baaaaa"]
my_dic = dict()
for i in my_list:
    my_dic[i] = len(i)

