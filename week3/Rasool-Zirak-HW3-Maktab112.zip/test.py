x = "3413523"
print("".join(sorted(x)))